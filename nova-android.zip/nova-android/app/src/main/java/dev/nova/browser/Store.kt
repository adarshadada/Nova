package dev.nova.browser

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger

val ENGINES = linkedMapOf(
    "DuckDuckGo" to "https://duckduckgo.com/?q=%s", "Google" to "https://www.google.com/search?q=%s",
    "Bing" to "https://www.bing.com/search?q=%s", "Brave Search" to "https://search.brave.com/search?q=%s",
    "Startpage" to "https://www.startpage.com/do/search?q=%s", "Ecosia" to "https://www.ecosia.org/search?q=%s")

fun host(u: String): String = try { Uri.parse(u).host ?: "" } catch (e: Exception) { "" }

class Store(ctx: Context) : SQLiteOpenHelper(ctx, "nova.db", null, 1) {
    private val p = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
    val total = AtomicInteger()
    @Volatile private var hosts: Set<String> = emptySet()
    @Volatile private var extra: Set<String> = emptySet()

    init {
        hosts = ctx.assets.open("blocklist.txt").bufferedReader().readLines().map { it.trim().lowercase() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toSet()
        extra = customHosts.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
    }

    var engine: String
        get() = p.getString("engine", "DuckDuckGo")!!
        set(v) = p.edit().putString("engine", v).apply()
    var customEngine: String
        get() = p.getString("customEngine", "")!!
        set(v) = p.edit().putString("customEngine", v).apply()
    var home: String
        get() = p.getString("home", "https://duckduckgo.com")!!
        set(v) = p.edit().putString("home", v).apply()
    var blocker: Boolean
        get() = p.getBoolean("blocker", true)
        set(v) = p.edit().putBoolean("blocker", v).apply()
    var allow: Set<String>
        get() = p.getStringSet("allow", emptySet())!!.toSet()
        set(v) = p.edit().putStringSet("allow", v.toSet()).apply()
    var session: List<String>
        get() = p.getString("session", "")!!.split("\n").filter { it.isNotBlank() }
        set(v) = p.edit().putString("session", v.joinToString("\n")).apply()
    var customHosts: String
        get() = p.getString("hosts", "")!!
        set(v) { p.edit().putString("hosts", v).apply(); extra = v.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet() }

    fun isBlocked(h0: String): Boolean {
        var h = h0.lowercase()
        while (h.contains('.')) { if (h in hosts || h in extra) return true; h = h.substringAfter('.') }
        return false
    }

    fun toUrl(input: String): String {
        val s = input.trim()
        if (s.isEmpty()) return home
        if (Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(s)) return s
        if (Regex("^(localhost|[\\w-]+(\\.[\\w-]+)+)(:\\d+)?(/\\S*)?$").matches(s)) return "https://$s"
        val tpl = if (engine == "Custom" && customEngine.contains("%s")) customEngine else ENGINES[engine] ?: ENGINES["DuckDuckGo"]!!
        return tpl.replace("%s", URLEncoder.encode(s, "UTF-8"))
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY, url TEXT, title TEXT, ts INTEGER)")
        d.execSQL("CREATE TABLE bookmarks(url TEXT PRIMARY KEY, title TEXT, ts INTEGER)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    private fun rows(sql: String, args: Array<String> = emptyArray()): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(sql, args).use { c -> while (c.moveToNext()) out += Pair(c.getString(0) ?: "", c.getString(1) ?: "") }
        return out
    }
    fun addHistory(u: String, t: String) { writableDatabase.execSQL("INSERT INTO history(url,title,ts) VALUES(?,?,?)", arrayOf<Any>(u, t, System.currentTimeMillis())) }
    fun history() = rows("SELECT title,url FROM history ORDER BY id DESC LIMIT 150")
    fun bookmarks() = rows("SELECT title,url FROM bookmarks ORDER BY ts DESC")
    fun isBookmarked(u: String) = rows("SELECT title,url FROM bookmarks WHERE url=?", arrayOf(u)).isNotEmpty()
    fun toggleBookmark(u: String, t: String): Boolean =
        if (isBookmarked(u)) { writableDatabase.execSQL("DELETE FROM bookmarks WHERE url=?", arrayOf<Any>(u)); false }
        else { writableDatabase.execSQL("INSERT INTO bookmarks VALUES(?,?,?)", arrayOf<Any>(u, t, System.currentTimeMillis())); true }
    fun clearHistory() { writableDatabase.execSQL("DELETE FROM history") }
    fun suggest(q: String): List<String> {
        val l = "%" + q.replace("%", "").replace("_", "") + "%"
        return rows("SELECT DISTINCT url,title FROM history WHERE url LIKE ? OR title LIKE ? ORDER BY id DESC LIMIT 6", arrayOf(l, l)).map { it.first }
    }
}
