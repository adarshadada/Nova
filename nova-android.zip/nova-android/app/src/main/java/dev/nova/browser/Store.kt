package dev.nova.browser

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger

val ENGINES = linkedMapOf(
    "DuckDuckGo" to "https://duckduckgo.com/?q=%s", "Google" to "https://www.google.com/search?q=%s",
    "Bing" to "https://www.bing.com/search?q=%s", "Brave Search" to "https://search.brave.com/search?q=%s",
    "Startpage" to "https://www.startpage.com/do/search?q=%s", "Ecosia" to "https://www.ecosia.org/search?q=%s")

fun host(u: String): String = try { Uri.parse(u).host ?: "" } catch (e: Exception) { "" }

class Store(ctx: Context) : SQLiteOpenHelper(ctx, "nova.db", null, 1) {
    private val p = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
    val total = AtomicInteger()
    @Volatile private var hosts: Set<String> = emptySet()
    @Volatile private var extra: Set<String> = emptySet()

    private val dir = ctx.filesDir
    @Volatile var cosmetic: List<String> = emptyList()

    init {
        hosts = ctx.assets.open("blocklist.txt").bufferedReader().readLines().map { it.trim().lowercase() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toSet()
        loadFilters()
        extra = customHosts.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
    }

    var engine: String
        get() = p.getString("engine", "DuckDuckGo")!!
        set(v) = p.edit().putString("engine", v).apply()
    var customEngine: String
        get() = p.getString("customEngine", "")!!
        set(v) = p.edit().putString("customEngine", v).apply()
    var home: String
        get() = p.getString("home", "nova:newtab")!!
        set(v) = p.edit().putString("home", v).apply()
    var blocker: Boolean
        get() = p.getBoolean("blocker", true)
        set(v) = p.edit().putBoolean("blocker", v).apply()
    var allow: Set<String>
        get() = p.getStringSet("allow", emptySet())!!.toSet()
        set(v) = p.edit().putStringSet("allow", v.toSet()).apply()
    var session: List<String>
        get() = p.getString("session", "")!!.split("\n").filter { it.isNotBlank() }
        set(v) = p.edit().putString("session", v.joinToString("\n")).apply()
    var customHosts: String
        get() = p.getString("hosts", "")!!
        set(v) { p.edit().putString("hosts", v).apply(); extra = v.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet() }

    var widgets: Set<String>
        get() = p.getStringSet("widgets", setOf("clock", "shortcuts", "bookmarks", "recent", "stats"))!!.toSet()
        set(v) = p.edit().putStringSet("widgets", v.toSet()).apply()
    fun zoom(h: String): Int = p.getInt("zoom:$h", 100)
    fun setZoom(h: String, z: Int) { p.edit().putInt("zoom:$h", z).apply() }
    fun searchTemplate(): String = if (engine == "Custom" && customEngine.contains("%s")) customEngine else ENGINES[engine] ?: ENGINES["DuckDuckGo"]!!

    private fun loadFilters() {
        try {
            val h = java.io.File(dir, "filters.txt"); if (h.exists()) hosts = hosts + h.readLines().toSet()
            val c = java.io.File(dir, "cosmetic.txt"); if (c.exists()) cosmetic = c.readLines()
        } catch (_: Exception) {}
    }

    fun updateLists(): Int {
        val hs = HashSet<String>(); val cs = ArrayList<String>()
        for (u in listOf("https://easylist.to/easylist/easylist.txt", "https://easylist.to/easylist/easyprivacy.txt")) {
            val conn = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 15000; conn.readTimeout = 30000
            conn.inputStream.bufferedReader().useLines { lines -> lines.forEach { l ->
                if (l.startsWith("||") && (l.endsWith("^") || l.endsWith("^\$third-party"))) {
                    val d = l.substring(2).substringBefore("^")
                    if (d.isNotEmpty() && d.all { it.isLetterOrDigit() || it == '.' || it == '-' }) hs.add(d.lowercase())
                } else if (l.startsWith("##") && l.length in 3..150 && !l.contains("+js(") && !l.contains(":-abp") && cs.size < 1500) cs.add(l.substring(2))
            } }
        }
        java.io.File(dir, "filters.txt").writeText(hs.joinToString("\n")); java.io.File(dir, "cosmetic.txt").writeText(cs.joinToString("\n"))
        hosts = hosts + hs; cosmetic = cs
        return hs.size
    }

    fun isBlocked(h0: String): Boolean {
        var h = h0.lowercase()
        while (h.contains('.')) { if (h in hosts || h in extra) return true; h = h.substringAfter('.') }
        return false
    }

    fun toUrl(input: String): String {
        val s = input.trim()
        if (s.isEmpty()) return home
        if (s == "nova:newtab") return s
        if (Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(s)) return s
        if (Regex("^(localhost|[\\w-]+(\\.[\\w-]+)+)(:\\d+)?(/\\S*)?$").matches(s)) return "https://$s"
        val tpl = if (engine == "Custom" && customEngine.contains("%s")) customEngine else ENGINES[engine] ?: ENGINES["DuckDuckGo"]!!
        return tpl.replace("%s", URLEncoder.encode(s, "UTF-8"))
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY, url TEXT, title TEXT, ts INTEGER)")
        d.execSQL("CREATE TABLE bookmarks(url TEXT PRIMARY KEY, title TEXT, ts INTEGER)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    private fun rows(sql: String, args: Array<String> = emptyArray()): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(sql, args).use { c -> while (c.moveToNext()) out += Pair(c.getString(0) ?: "", c.getString(1) ?: "") }
        return out
    }
    fun addHistory(u: String, t: String) { writableDatabase.execSQL("INSERT INTO history(url,title,ts) VALUES(?,?,?)", arrayOf<Any>(u, t, System.currentTimeMillis())) }
    fun history() = rows("SELECT title,url FROM history ORDER BY id DESC LIMIT 150")
    fun bookmarks() = rows("SELECT title,url FROM bookmarks ORDER BY ts DESC")
    fun isBookmarked(u: String) = rows("SELECT title,url FROM bookmarks WHERE url=?", arrayOf(u)).isNotEmpty()
    fun toggleBookmark(u: String, t: String): Boolean =
        if (isBookmarked(u)) { writableDatabase.execSQL("DELETE FROM bookmarks WHERE url=?", arrayOf<Any>(u)); false }
        else { writableDatabase.execSQL("INSERT INTO bookmarks VALUES(?,?,?)", arrayOf<Any>(u, t, System.currentTimeMillis())); true }
    fun topSites() = rows("SELECT title,url FROM history GROUP BY url ORDER BY COUNT(*) DESC LIMIT 8")
    fun historyCount(): String = rows("SELECT COUNT(*),'' FROM history").firstOrNull()?.first ?: "0"
    fun clearHistory() { writableDatabase.execSQL("DELETE FROM history") }
    fun suggest(q: String): List<String> {
        val l = "%" + q.replace("%", "").replace("_", "") + "%"
        return rows("SELECT DISTINCT url,title FROM history WHERE url LIKE ? OR title LIKE ? ORDER BY id DESC LIMIT 6", arrayOf(l, l)).map { it.first }
    }
}
