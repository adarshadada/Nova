package dev.nova.browser

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicInteger

class Tab(val wv: WebView, val priv: Boolean) {
    var title = "New tab"; var url = ""; var desktop = false; val blocked = AtomicInteger()
}

class MainActivity : Activity() {
    private lateinit var st: Store
    private val tabs = mutableListOf<Tab>()
    private var cur: Tab? = null
    private lateinit var addr: AutoCompleteTextView
    private lateinit var frame: FrameLayout
    private lateinit var bar: ProgressBar
    private lateinit var shield: TextView
    private lateinit var tabBtn: TextView
    private val sug = mutableListOf<String>()
    private var full: View? = null
    private var fullCb: WebChromeClient.CustomViewCallback? = null
    private var pending: (() -> Unit)? = null
    private val ui = Handler(Looper.getMainLooper())
    private val risky = Regex(".*\\.(apk|exe|msi|bat|sh|jar|scr|dmg)$", RegexOption.IGNORE_CASE)
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun label(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); st = Store(this)
        try { if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) ProfileStore.getInstance().deleteProfile("private") } catch (_: Exception) {}
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, sug) {
            override fun getFilter() = object : Filter() {
                override fun performFiltering(c: CharSequence?) = FilterResults().apply { values = sug; count = sug.size }
                override fun publishResults(c: CharSequence?, r: FilterResults?) { notifyDataSetChanged() }
            }
        }
        addr = AutoCompleteTextView(this).apply {
            hint = "Search or enter address"; setSingleLine(); threshold = 1; setAdapter(adapter)
            imeOptions = EditorInfo.IME_ACTION_GO; inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setOnFocusChangeListener { v, f -> if (f) (v as EditText).selectAll() }
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
            setOnItemClickListener { p, _, i, _ -> go(p.getItemAtPosition(i) as String) }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) {}
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                    sug.clear(); if (hasFocus() && !s.isNullOrBlank()) sug.addAll(st.suggest(s.toString())); adapter.notifyDataSetChanged()
                }
            })
        }
        shield = label("") { shieldDialog() }.apply { textSize = 14f }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(shield); addView(addr, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(label("⋮") { menu(it) })
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        frame = FrameLayout(this)
        tabBtn = label("1") { tabDialog() }.apply { textSize = 16f }
        val bottom = LinearLayout(this)
        listOf(label("‹") { cur?.wv?.goBack() }, label("›") { cur?.wv?.goForward() }, label("⌂") { cur?.wv?.loadUrl(st.home) },
            label("+") { newTab(st.home) }, tabBtn).forEach { bottom.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(top); addView(bar, LinearLayout.LayoutParams(-1, dp(3)))
            addView(frame, LinearLayout.LayoutParams(-1, 0, 1f)); addView(bottom)
        }
        setContentView(root)
        val first = intent?.data?.toString()
        if (first != null) newTab(first) else if (st.session.isNotEmpty()) st.session.forEach { newTab(it) } else newTab(st.home)
        ui.post(object : Runnable { override fun run() { refresh(); ui.postDelayed(this, 1000) } })
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); i?.data?.let { newTab(it.toString()) } }
    override fun onPause() { super.onPause(); st.session = tabs.filter { !it.priv && it.url.startsWith("http") }.map { it.url } }
    override fun onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { pending?.invoke(); pending = null }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val t = cur
        when { full != null -> hideFull(); t != null && t.wv.canGoBack() -> t.wv.goBack(); tabs.size > 1 && t != null -> closeTab(t); else -> super.onBackPressed() }
    }

    private fun go(s: String) {
        cur?.wv?.loadUrl(st.toUrl(s)); addr.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(addr.windowToken, 0)
    }

    private fun newTab(url: String, priv: Boolean = false, load: Boolean = true): Tab? {
        if (priv && !WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Private tabs need a newer Android System WebView", Toast.LENGTH_LONG).show(); return null
        }
        val wv = WebView(this); val t = Tab(wv, priv)
        if (priv) { ProfileStore.getInstance().getOrCreateProfile("private"); WebViewCompat.setProfile(wv, "private") }
        wv.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; setSupportMultipleWindows(true); javaScriptCanOpenWindowsAutomatically = false
            allowFileAccess = false; allowContentAccess = false; safeBrowsingEnabled = true
            builtInZoomControls = true; displayZoomControls = false
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !st.blocker)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (!st.blocker) return null
                val top = host(t.url); if (top in st.allow) return null
                val h = r.url.host ?: return null
                if (h != top && !h.endsWith(".$top") && st.isBlocked(h)) {
                    t.blocked.incrementAndGet(); st.total.incrementAndGet()
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: return true
                if (s == "http" || s == "https") return false
                if (s == "mailto" || s == "tel") try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: Exception) {}
                return true
            }
            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) { t.url = u; t.blocked.set(0); if (cur == t) addr.setText(u); refresh() }
            override fun onPageFinished(v: WebView, u: String) {
                t.url = u; t.title = v.title ?: u; bar.visibility = View.GONE
                if (!t.priv && u.startsWith("http")) st.addHistory(u, t.title)
                if (cur == t && !addr.hasFocus()) addr.setText(u); refresh()
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { if (cur == t) { bar.progress = p; bar.visibility = if (p < 100) View.VISIBLE else View.GONE } }
            override fun onReceivedTitle(v: WebView, title: String?) { t.title = title ?: t.title }
            override fun onCreateWindow(v: WebView, d: Boolean, u: Boolean, m: Message): Boolean {
                val nt = newTab("about:blank", t.priv, false) ?: return false
                (m.obj as WebView.WebViewTransport).webView = nt.wv; m.sendToTarget(); return true
            }
            override fun onPermissionRequest(req: PermissionRequest) {
                val perms = mutableListOf<String>()
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in req.resources) perms += Manifest.permission.CAMERA
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in req.resources) perms += Manifest.permission.RECORD_AUDIO
                if (perms.isEmpty()) req.deny() else askPerm(req.origin.host ?: "", "camera/microphone", perms.toTypedArray()) { if (it) req.grant(req.resources) else req.deny() }
            }
            override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) =
                askPerm(host(o), "location", arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)) { cb.invoke(o, it, false) }
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                full = v; fullCb = cb; (window.decorView as ViewGroup).addView(v); window.insetsController?.hide(WindowInsets.Type.systemBars())
            }
            override fun onHideCustomView() { hideFull() }
        }
        wv.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }
        wv.setFindListener { i, n, _ -> if (n >= 0) Toast.makeText(this, if (n == 0) "No matches" else "${i + 1}/$n", Toast.LENGTH_SHORT).show() }
        tabs.add(t); select(t)
        if (load) wv.loadUrl(st.toUrl(url))
        return t
    }

    private fun hideFull() {
        full?.let { (window.decorView as ViewGroup).removeView(it) }; full = null; fullCb?.onCustomViewHidden()
        window.insetsController?.show(WindowInsets.Type.systemBars())
    }
    private fun select(t: Tab) { cur?.wv?.onPause(); frame.removeAllViews(); frame.addView(t.wv); cur = t; t.wv.onResume(); addr.setText(t.url); refresh() }
    private fun closeTab(t: Tab) {
        val i = tabs.indexOf(t); tabs.remove(t); frame.removeView(t.wv); t.wv.destroy()
        if (t.priv && tabs.none { it.priv }) try { ProfileStore.getInstance().deleteProfile("private") } catch (_: Exception) {}
        if (tabs.isEmpty()) newTab(st.home) else select(tabs[minOf(i, tabs.size - 1)])
    }
    private fun refresh() {
        val t = cur ?: return; tabBtn.text = "${tabs.size}"
        val lock = if (t.url.startsWith("https://")) "🔒" else if (t.url.startsWith("http://")) "⚠" else ""
        shield.text = lock + (if (st.blocker && host(t.url) !in st.allow) "⛨" else "⛉") + t.blocked.get() + if (t.priv) " 🕶" else ""
    }

    private fun askPerm(origin: String, what: String, perms: Array<String>, ok: (Boolean) -> Unit) {
        AlertDialog.Builder(this).setMessage("$origin wants to use your $what")
            .setPositiveButton("Allow") { _, _ ->
                val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                if (need.isEmpty()) ok(true) else { pending = { ok(perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) }; requestPermissions(need.toTypedArray(), 1) }
            }.setNegativeButton("Block") { _, _ -> ok(false) }.setOnCancelListener { ok(false) }.show()
    }

    private fun download(u: String, ua: String, cd: String, mime: String) {
        if (!u.startsWith("http")) return
        val fn = URLUtil.guessFileName(u, cd, mime)
        val start = {
            val r = DownloadManager.Request(Uri.parse(u)).setMimeType(mime).addRequestHeader("User-Agent", ua)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn)
            CookieManager.getInstance().getCookie(u)?.let { r.addRequestHeader("Cookie", it) }
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            Toast.makeText(this, "Downloading $fn", Toast.LENGTH_SHORT).show()
        }
        if (risky.matches(fn)) AlertDialog.Builder(this).setMessage("\"$fn\" can run code on your device. Only keep it if you trust the source.")
            .setPositiveButton("Keep") { _, _ -> start() }.setNegativeButton("Cancel", null).show() else start()
    }

    private fun shieldDialog() {
        val t = cur ?: return; val h = host(t.url); val on = st.blocker && h !in st.allow
        AlertDialog.Builder(this).setTitle(h.ifEmpty { "NOVA" })
            .setMessage("Protection: ${if (on) "ON" else "OFF"}\nBlocked on this page: ${t.blocked.get()}\nBlocked this session: ${st.total.get()}\nConnection: ${if (t.url.startsWith("https://")) "HTTPS" else "not secure"}\n\nBlocking uses a bundled host list and does not stop every ad.")
            .setPositiveButton(if (h in st.allow) "Enable for this site" else "Disable for this site") { _, _ -> st.allow = if (h in st.allow) st.allow - h else st.allow + h; t.wv.reload() }
            .setNeutralButton(if (st.blocker) "Turn off everywhere" else "Turn on everywhere") { _, _ -> st.blocker = !st.blocker; tabs.forEach { CookieManager.getInstance().setAcceptThirdPartyCookies(it.wv, !st.blocker) }; t.wv.reload() }
            .setNegativeButton("Close", null).show()
    }

    private fun tabDialog() {
        val b = AlertDialog.Builder(this).setTitle("Tabs")
            .setItems(tabs.map { (if (it.priv) "🕶 " else "") + it.title }.toTypedArray()) { _, i -> select(tabs[i]) }
            .setPositiveButton("New tab") { _, _ -> newTab(st.home) }
            .setNegativeButton("Close current") { _, _ -> cur?.let { closeTab(it) } }
        b.show()
    }

    private fun list(title: String, rows: List<Pair<String, String>>) {
        if (rows.isEmpty()) { Toast.makeText(this, "Nothing here yet", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle(title).setItems(rows.map { it.first.ifBlank { it.second } }.toTypedArray()) { _, i -> cur?.wv?.loadUrl(rows[i].second) }.show()
    }
    private fun prompt(title: String, init: String, ok: (String) -> Unit) {
        val e = EditText(this).apply { setText(init); setSingleLine() }
        AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("OK") { _, _ -> ok(e.text.toString().trim()) }.setNegativeButton("Cancel", null).show()
    }

    private fun menu(v: View) {
        val names = listOf("New tab", "New private tab", "Bookmark / unbookmark", "Bookmarks", "History", "Downloads", "Find in page", "Desktop site on/off",
            "Search engine…", "Home page…", "Extra blocked hosts…", "Clear browsing data", "Share page")
        PopupMenu(this, v).apply {
            names.forEachIndexed { i, s -> menu.add(0, i, i, s) }
            setOnMenuItemClickListener { m ->
                val t = cur
                when (m.itemId) {
                    0 -> newTab(st.home); 1 -> newTab(st.home, true)
                    2 -> if (t != null && t.url.startsWith("http")) Toast.makeText(this@MainActivity, if (st.toggleBookmark(t.url, t.title)) "Bookmarked" else "Removed", Toast.LENGTH_SHORT).show()
                    3 -> list("Bookmarks", st.bookmarks()); 4 -> list("History", st.history())
                    5 -> startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                    6 -> prompt("Find in page", "") { q -> t?.wv?.findAllAsync(q) }
                    7 -> t?.let {
                        it.desktop = !it.desktop; val s = it.wv.settings
                        s.userAgentString = if (it.desktop) WebSettings.getDefaultUserAgent(this@MainActivity).replace(Regex("\\(.*?\\)"), "(X11; Linux x86_64)").replace(" Mobile", "") else null
                        s.useWideViewPort = it.desktop; s.loadWithOverviewMode = it.desktop; it.wv.reload()
                    }
                    8 -> { val n = ENGINES.keys.toList() + "Custom"
                        AlertDialog.Builder(this@MainActivity).setTitle("Search engine").setSingleChoiceItems(n.toTypedArray(), n.indexOf(st.engine)) { d, i ->
                            d.dismiss(); st.engine = n[i]
                            if (n[i] == "Custom") prompt("Search URL (use %s for the query)", st.customEngine) { st.customEngine = it }
                        }.show() }
                    9 -> prompt("Home page", st.home) { if (it.startsWith("https://") || it.startsWith("http://")) st.home = it }
                    10 -> prompt("Blocked hosts (comma separated)", st.customHosts) { st.customHosts = it }
                    11 -> AlertDialog.Builder(this@MainActivity).setMessage("Clear history, cookies, site data and cache?").setPositiveButton("Clear") { _, _ ->
                        st.clearHistory(); CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData(); tabs.forEach { it.wv.clearCache(true) }
                    }.setNegativeButton("Cancel", null).show()
                    12 -> if (t != null) startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.url), "Share"))
                }
                true
            }
            show()
        }
    }
}
