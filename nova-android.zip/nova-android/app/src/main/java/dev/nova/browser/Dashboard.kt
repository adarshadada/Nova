package dev.nova.browser

fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

private val QUICK = listOf("Wikipedia" to "https://www.wikipedia.org", "YouTube" to "https://www.youtube.com", "GitHub" to "https://github.com",
    "Reddit" to "https://www.reddit.com", "OpenStreetMap" to "https://www.openstreetmap.org", "Hacker News" to "https://news.ycombinator.com",
    "Internet Archive" to "https://archive.org", "Weather" to "https://wttr.in")

private fun icon(url: String): String {
    val h = host(url); val l = esc(h.removePrefix("www.").take(1).uppercase())
    return "<i data-l=\"$l\"><img src=\"https://icons.duckduckgo.com/ip3/" + esc(h) + ".ico\" onerror=\"this.remove()\"></i>"
}
private fun tile(title: String, url: String): String {
    val label = title.ifBlank { host(url).removePrefix("www.") }.take(14)
    return "<a class=t href=\"" + esc(url) + "\">" + icon(url) + "<span>" + esc(label) + "</span></a>"
}
private fun row(title: String, url: String): String =
    "<a class=r href=\"" + esc(url) + "\">" + icon(url) + "<div><b>" + esc(title.ifBlank { host(url) }.take(60)) + "</b><small>" + esc(host(url)) + "</small></div></a>"
private fun section(name: String, rows: List<Pair<String, String>>): String =
    if (rows.isEmpty()) "" else "<h3>$name</h3><div class=l>" + rows.joinToString("") { row(it.first, it.second) } + "</div>"

private const val CSS = """
:root{color-scheme:light dark;--bg:#f3f4f8;--s:#fff;--t:#1c1e24;--m:#6b7080;--a:#4f7cff;--l:#0001}
@media(prefers-color-scheme:dark){:root{--bg:#16181d;--s:#262a33;--t:#eceef3;--m:#9aa0b0;--l:#fff1}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:auto;background:var(--bg);color:var(--t);font:15px/1.4 system-ui,sans-serif;padding:28px 18px 40px;max-width:560px}
#c{font-size:54px;font-weight:200;letter-spacing:-1px;line-height:1}#g{color:var(--m);margin:6px 0 22px}
form{position:relative;margin-bottom:26px}form svg{position:absolute;left:16px;top:15px;width:22px;height:22px;fill:var(--m)}
form input{width:100%;height:52px;border:0;border-radius:26px;padding:0 20px 0 48px;background:var(--s);color:var(--t);font:inherit;font-size:16px;box-shadow:0 1px 3px #0002;outline:none}
form input:focus{box-shadow:0 0 0 2px var(--a)}
h3{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--m);margin:26px 4px 10px;font-weight:600}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:14px 8px}
.t{display:flex;flex-direction:column;align-items:center;gap:7px;text-decoration:none;color:var(--t);font-size:12px;min-width:0}
.t span{max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
i{position:relative;display:flex;align-items:center;justify-content:center;width:52px;height:52px;border-radius:16px;background:var(--s);box-shadow:0 1px 3px #0002;font-style:normal;font-weight:600;color:var(--a);font-size:20px;overflow:hidden;flex:none}
i::before{content:attr(data-l)}i img{position:absolute;inset:0;margin:auto;width:30px;height:30px;border-radius:7px;background:var(--s)}
.l{background:var(--s);border-radius:18px;overflow:hidden;box-shadow:0 1px 3px #0002}
.r{display:flex;align-items:center;gap:12px;padding:10px 14px;text-decoration:none;color:var(--t);border-top:1px solid var(--l)}.r:first-child{border-top:0}
.r i{width:36px;height:36px;border-radius:11px;font-size:15px;box-shadow:none;background:var(--l)}.r i img{width:20px;height:20px}
.r div{min-width:0}.r b{display:block;font-weight:500;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.r small{color:var(--m)}
.s{display:grid;grid-template-columns:1fr 1fr;gap:10px}.s div{background:var(--s);border-radius:18px;padding:16px;box-shadow:0 1px 3px #0002}
.s b{display:block;font-size:30px;font-weight:300;color:var(--a)}.s small{color:var(--m)}
"""

fun dashboardHtml(st: Store): String {
    val w = st.widgets
    val tpl = st.searchTemplate().replace("\\", "\\\\").replace("\"", "\\\"").replace("<", "\\u003c")
    val sb = StringBuilder()
    sb.append("<!doctype html><html><head><meta charset=utf-8><meta name=viewport content=\"width=device-width,initial-scale=1\"><style>").append(CSS).append("</style></head><body>")
    sb.append("<div id=c></div><div id=g></div>")
    sb.append("<form onsubmit=\"go(event)\"><svg viewBox=\"0 0 24 24\"><path d=\"M15.5,14h-0.79l-0.28,-0.27C15.41,12.59 16,11.11 16,9.5 16,5.91 13.09,3 9.5,3S3,5.91 3,9.5 5.91,16 9.5,16c1.61,0 3.09,-0.59 4.23,-1.57l0.27,0.28v0.79l5,4.99L20.49,19l-4.99,-5zM9.5,14C7.01,14 5,11.99 5,9.5S7.01,5 9.5,5 14,7.01 14,9.5 11.99,14 9.5,14z\"/></svg><input id=q placeholder=\"Search or type a URL\" autocomplete=off></form>")
    if ("clock" in w) sb.append("<script>function t(){var d=new Date(),h=d.getHours();c.textContent=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});g.textContent=(h<12?'Good morning':h<18?'Good afternoon':'Good evening')+' \u00B7 '+d.toLocaleDateString([],{weekday:'long',month:'long',day:'numeric'})}t();setInterval(t,10000)</script>")
    sb.append("<script>var T=\"").append(tpl).append("\";function go(e){e.preventDefault();location.href=T.replace('%s',encodeURIComponent(q.value))}</script>")
    if ("shortcuts" in w) {
        val sites = (st.topSites() + QUICK).distinctBy { host(it.second) }.take(8)
        sb.append("<h3>Shortcuts</h3><div class=g>").append(sites.joinToString("") { tile(it.first, it.second) }).append("</div>")
    }
    if ("bookmarks" in w) sb.append(section("Bookmarks", st.bookmarks().take(6)))
    if ("recent" in w) sb.append(section("Recent", st.history().take(6)))
    if ("stats" in w) sb.append("<h3>Privacy</h3><div class=s><div><b>").append(st.total.get()).append("</b><small>blocked this session</small></div><div><b>").append(st.historyCount()).append("</b><small>pages in history</small></div></div>")
    sb.append("</body></html>")
    return sb.toString()
}
