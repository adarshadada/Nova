plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "dev.nova.browser"
    compileSdk = 34
    defaultConfig { applicationId = "dev.nova.browser"; minSdk = 30; targetSdk = 34; versionCode = 1; versionName = "0.1.0" }
    buildTypes { release { isMinifyEnabled = true; isShrinkResources = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.webkit:webkit:1.12.1") }
