# NOVA Browser for Android (v0.1 core)
Kotlin app using the system Chromium (Android System WebView). minSdk 30.

## Build
Open in Android Studio (it creates the Gradle wrapper) and Run, or: `gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).
APK: app/build/outputs/apk/debug/. For release, add your own signing config and run `gradle assembleRelease`.

## Implemented
Multiple tabs (switcher, close, popup tabs), address bar with URL detection, history suggestions, 6 engines + custom, request-level tracker blocker (real counters, per-site and global toggle, extra hosts, third-party cookies blocked when on), HTTPS/insecure indicator, SQLite history + bookmarks, system DownloadManager downloads with risky-file warning, camera/mic/location prompts, private tabs (isolated WebView profile, deleted on close), fullscreen video, find in page, desktop-site mode, share, clear data, default-browser intent filters, session restore, Safe Browsing.

## Limitations (honest)
- No extensions: Android System WebView does not support them.
- Blocker uses a small bundled host list (no EasyList parsing or cosmetic filtering yet); WebView cannot filter by URL path rules cheaply.
- Private tabs require a WebView with multi-profile support; otherwise they are refused.
- No DNS-over-HTTPS toggle (use Android Private DNS), no profiles, tab groups, split view, reader mode, new-tab dashboard, password manager, translation.
- Not compiled or tested yet: build and smoke-test before relying on it.

## v0.2 additions
New-tab dashboard (clock, greeting, search, most visited, bookmarks, recent, privacy stats; widgets toggleable), EasyList/EasyPrivacy download (host rules + generic cosmetic rules), pinned tabs, tab search, reader mode, screenshot (Pictures/NOVA), print / save PDF, QR code, translate (opens Google Translate), per-site zoom, per-site cookie clearing, picture-in-picture (whole window), widgets setting.
Not possible / not built: extensions, web notifications (WebView lacks them), built-in password vault (use Android Autofill), tab groups, split view, profiles, bookmark folders, wallpapers, shortcut customization, DoH toggle (use Private DNS).
