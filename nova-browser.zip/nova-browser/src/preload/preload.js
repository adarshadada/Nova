'use strict';
const { contextBridge, ipcRenderer } = require('electron');
const CH = new Set(['state', 'dl', 'focus-address']);
contextBridge.exposeInMainWorld('nova', {
  act: (a) => ipcRenderer.invoke('act', a),
  suggest: (q) => ipcRenderer.invoke('suggest', String(q)),
  data: (k) => ipcRenderer.invoke('data', String(k)),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSetting: (k, v) => ipcRenderer.invoke('settings:set', String(k), v),
  on: (ch, cb) => { if (CH.has(ch)) ipcRenderer.on(ch, (_e, d) => cb(d)); }
});
