'use strict';
const $ = (s) => document.querySelector(s);
const h = (tag, p = {}, ...kids) => { const e = document.createElement(tag); for (const k in p) { if (k === 'class') e.className = p[k]; else if (k.startsWith('on')) e.addEventListener(k.slice(2), p[k]); else if (k === 'text') e.textContent = p[k]; else e[k] = p[k]; } kids.flat().forEach((c) => c && e.append(c)); return e; };
const act = (type, o = {}) => window.nova.act({ type, ...o });
let S = null, addr, shield, star, back, fwd, selIdx = -1, items = [], tmr;

const btn = (t, title, fn) => h('button', { class: 'b', title, text: t, onclick: fn });
function buildBar() {
  back = btn('‹', 'Back', () => act('back')); fwd = btn('›', 'Forward', () => act('fwd'));
  shield = btn('⛨', 'Protection', () => act('shield')); star = btn('☆', 'Bookmark', () => act('bookmark'));
  addr = h('input', { id: 'addr', type: 'text', placeholder: 'Search or enter address', spellcheck: false });
  addr.addEventListener('focus', () => addr.select());
  addr.addEventListener('input', () => { clearTimeout(tmr); tmr = setTimeout(suggest, 120); });
  addr.addEventListener('keydown', (e) => {
    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && items.length) { e.preventDefault(); selIdx = (selIdx + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length; markSel(); }
    else if (e.key === 'Enter') { const v = selIdx >= 0 ? items[selIdx].text : addr.value; closeSugg(); act('nav', { value: v }); addr.blur(); }
    else if (e.key === 'Escape') { closeSugg(); addr.blur(); if (S) addr.value = S.url; }
  });
  addr.addEventListener('blur', () => setTimeout(closeSugg, 150));
  $('#bar').append(back, fwd, btn('⟳', 'Reload', () => act('reload')), btn('⌂', 'Home', () => act('home')), shield, addr, star,
    btn('⤓', 'Downloads', () => openPanel('downloads')), btn('⌥', 'Developer tools (F12)', () => act('devtools')), btn('≡', 'Menu & settings', () => openPanel('settings')));
}
async function suggest() {
  const q = addr.value; if (!q.trim()) return closeSugg();
  items = await window.nova.suggest(q); selIdx = -1;
  const box = $('#sugg');
  box.replaceChildren(...items.map((it) => h('div', { onmousedown: () => { closeSugg(); act('nav', { value: it.text }); } }, document.createTextNode((it.kind === 'search' ? '🔍 ' : '🕘 ') + it.text), it.sub ? h('small', { text: it.sub }) : null)));
  box.hidden = !items.length; act('overlay', { value: !!items.length });
}
function markSel() { [...$('#sugg').children].forEach((c, i) => c.classList.toggle('sel', i === selIdx)); }
function closeSugg() { $('#sugg').hidden = true; items = []; if ($('#panel').hidden) act('overlay', { value: false }); }

function render(s) {
  S = s; const r = document.documentElement; r.dataset.t = s.theme; r.style.setProperty('--accent', s.accent);
  $('#tabs').replaceChildren(...s.tabs.map((t) => h('div', { class: 'tab' + (t.id === s.active ? ' on' : '') + (t.pinned ? ' pin' : ''), title: t.title + '\nRight-click: pin/unpin', onclick: () => act('select', { id: t.id }),
    onauxclick: () => act('close', { id: t.id }), oncontextmenu: (e) => { e.preventDefault(); act('pin', { id: t.id }); } },
    t.favicon ? h('img', { src: t.favicon, alt: '' }) : h('span', { text: t.loading ? '…' : '○' }),
    h('span', { class: 'tt', text: t.title }),
    t.audible || t.muted ? h('span', { text: t.muted ? '🔇' : '🔊', title: 'Mute/unmute', onclick: (e) => { e.stopPropagation(); act('mute', { id: t.id }); } }) : null,
    t.pinned ? null : h('button', { class: 'x', text: '×', onclick: (e) => { e.stopPropagation(); act('close', { id: t.id }); } }))),
    s.priv ? h('span', { class: 'badge', text: 'Private' }) : null, btn('+', 'New tab (Ctrl+T)', () => act('new')), btn('◐', 'Private window', () => act('private')));
  if (document.activeElement !== addr) addr.value = s.url;
  back.disabled = !s.canBack; fwd.disabled = !s.canFwd;
  star.textContent = s.bookmarked ? '★' : '☆'; star.classList.toggle('on', s.bookmarked);
  shield.classList.toggle('off', !s.protection);
  shield.title = `Protection ${s.protection ? 'ON' : 'OFF'} for this site • ${s.blocked} blocked on this page • ${s.totalBlocked} this session (click to toggle)`;
}

async function openPanel(kind) {
  const p = $('#panel'); p.hidden = false; act('overlay', { value: true });
  const nav = h('div', { class: 'nav' }, ...['settings', 'history', 'bookmarks', 'downloads'].map((k) => h('button', { class: k === kind ? 'on' : '', text: k[0].toUpperCase() + k.slice(1), onclick: () => openPanel(k) })), h('button', { text: 'Close', onclick: closePanel }));
  let body;
  if (kind === 'settings') body = await settingsView();
  else {
    const rows = await window.nova.data(kind);
    body = h('div', {}, rows.length ? rows.map((r) => h('div', { class: 'li', onclick: () => { if (r.url) { closePanel(); act('new', { url: r.url }); } } }, h('span', { text: r.title || r.name || r.url }), h('small', { text: r.url || r.state }))) : h('p', { text: 'Nothing here yet.' }));
  }
  p.replaceChildren(nav, body);
}
function closePanel() { $('#panel').hidden = true; act('overlay', { value: false }); }
async function settingsView() {
  const st = await window.nova.getSettings(); const set = (k, v) => window.nova.setSetting(k, v);
  const sel = (k, opts) => h('select', { onchange: (e) => set(k, e.target.value) }, opts.map((o) => h('option', { value: o, text: o, selected: o === st[k] })));
  const txt = (k) => h('input', { type: 'text', value: st[k], onchange: (e) => set(k, e.target.value) });
  const chk = (k) => h('input', { type: 'checkbox', checked: st[k], onchange: (e) => set(k, e.target.checked) });
  const row = (l, c) => h('div', { class: 'row' }, h('label', { text: l }), c);
  return h('div', {}, h('h2', { text: 'Settings' }),
    row('Search engine', sel('engine', ['duckduckgo', 'google', 'bing', 'brave', 'startpage', 'ecosia', 'custom'])),
    row('Custom engine URL (use %s)', txt('customEngine')), row('Home / new tab page', txt('home')),
    row('Theme', sel('theme', ['system', 'light', 'dark'])), row('Accent colour', h('input', { type: 'color', value: st.accent, onchange: (e) => set('accent', e.target.value) })),
    row('Ad & tracker blocking', chk('blocker')), row('DNS-over-HTTPS (Cloudflare)', chk('doh')),
    row('Extra blocked hosts (one per line)', h('textarea', { rows: 4, value: st.customHosts.join('\n'), onchange: (e) => set('customHosts', e.target.value.split('\n').map((x) => x.trim()).filter(Boolean)) })),
    h('button', { class: 'btn', text: 'Clear history, cookies & cache', onclick: () => act('clear') }),
    h('button', { class: 'btn', text: 'Reopen closed tab', onclick: () => { closePanel(); act('reopen'); } }));
}

buildBar();
window.nova.on('state', render);
window.nova.on('dl', () => { if (!$('#panel').hidden && document.querySelector('.nav .on').textContent === 'Downloads') openPanel('downloads'); });
window.nova.on('focus-address', () => addr.focus());
