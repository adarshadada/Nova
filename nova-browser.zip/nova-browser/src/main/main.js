'use strict';
const { app, BrowserWindow, WebContentsView, ipcMain, session, dialog, net } = require('electron');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const CHROME_H = 84;
const ENGINES = {
  duckduckgo: 'https://duckduckgo.com/?q=%s', google: 'https://www.google.com/search?q=%s',
  bing: 'https://www.bing.com/search?q=%s', brave: 'https://search.brave.com/search?q=%s',
  startpage: 'https://www.startpage.com/do/search?q=%s', ecosia: 'https://www.ecosia.org/search?q=%s'
};
const DEFAULTS = {
  engine: 'duckduckgo', customEngine: '', home: 'https://duckduckgo.com', theme: 'system', accent: '#4f7cff',
  blocker: true, doh: false, allowlist: [], customHosts: [], permissions: {}, session: []
};
const RISKY = /\.(exe|msi|bat|cmd|scr|ps1|sh|jar|apk|dmg|com|vbs)$/i;
let settings, db, blockHosts = new Set(), totalBlocked = 0;
const wins = new Set(), dls = new Map(), prepared = new Set();

/* ---------- settings ---------- */
const sFile = () => path.join(app.getPath('userData'), 'settings.json');
function loadSettings() { try { settings = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(sFile(), 'utf8')) }; } catch { settings = { ...DEFAULTS }; } }
function saveSettings() { fs.writeFileSync(sFile(), JSON.stringify(settings, null, 2)); }

/* ---------- database ---------- */
function initDb() {
  db = new Database(path.join(app.getPath('userData'), 'nova.db'));
  db.exec(`CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY,url TEXT,title TEXT,ts INTEGER);
  CREATE TABLE IF NOT EXISTS bookmarks(url TEXT PRIMARY KEY,title TEXT,ts INTEGER);
  CREATE TABLE IF NOT EXISTS downloads(id INTEGER PRIMARY KEY,name TEXT,path TEXT,state TEXT,ts INTEGER);`);
}

/* ---------- blocker ---------- */
function loadBlocklist() {
  const s = new Set();
  const add = (t) => t.split('\n').forEach((l) => { l = l.trim().toLowerCase().replace(/^(0\.0\.0\.0|127\.0\.0\.1)\s+/, ''); if (l && !l.startsWith('#')) s.add(l); });
  add(fs.readFileSync(path.join(__dirname, 'blocklist.txt'), 'utf8'));
  settings.customHosts.forEach((h) => s.add(String(h).toLowerCase()));
  blockHosts = s;
}
function isBlocked(host) { for (let h = host; h.includes('.'); h = h.slice(h.indexOf('.') + 1)) if (blockHosts.has(h)) return true; return false; }
const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ''; } };
function tabByWc(id) { for (const w of wins) for (const t of w.tabs.values()) if (t.view.webContents.id === id) return t; return null; }

/* ---------- search ---------- */
function toUrl(input) {
  input = String(input || '').trim();
  if (!input) return settings.home;
  if (/^https?:\/\//i.test(input)) return input;
  if (/^(localhost|[\w-]+(\.[\w-]+)+)(:\d+)?(\/\S*)?$/.test(input)) return 'https://' + input;
  const tpl = settings.engine === 'custom' && settings.customEngine.includes('%s') ? settings.customEngine : ENGINES[settings.engine] || ENGINES.duckduckgo;
  return tpl.replace('%s', encodeURIComponent(input));
}

/* ---------- sessions ---------- */
function prepare(ses, priv) {
  if (prepared.has(ses)) return; prepared.add(ses);
  ses.webRequest.onBeforeRequest((d, cb) => {
    if (!settings.blocker) return cb({});
    const host = hostOf(d.url); if (!host || !/^https?:/.test(d.url)) return cb({});
    const tab = d.webContentsId ? tabByWc(d.webContentsId) : null;
    const top = tab ? hostOf(tab.view.webContents.getURL()) : '';
    if (top && settings.allowlist.includes(top)) return cb({});
    if (isBlocked(host) && host !== top && !host.endsWith('.' + top)) { if (tab) tab.blocked++; totalBlocked++; return cb({ cancel: true }); }
    cb({});
  });
  ses.webRequest.onBeforeSendHeaders((d, cb) => { d.requestHeaders['DNT'] = '1'; d.requestHeaders['Sec-GPC'] = '1'; cb({ requestHeaders: d.requestHeaders }); });
  ses.setPermissionRequestHandler(async (wc, perm, cb, det) => {
    if (['fullscreen', 'clipboard-sanitized-write'].includes(perm)) return cb(true);
    if (!['media', 'geolocation', 'notifications', 'clipboard-read'].includes(perm)) return cb(false);
    const key = hostOf(det.requestingUrl) + '|' + perm;
    if (key in settings.permissions) return cb(settings.permissions[key]);
    const win = BrowserWindow.getAllWindows().find((b) => !b.isDestroyed());
    const r = await dialog.showMessageBox(win, { type: 'question', buttons: ['Allow', 'Block'], message: `${hostOf(det.requestingUrl)} wants permission: ${perm}`, checkboxLabel: 'Remember my choice' });
    const ok = r.response === 0;
    if (r.checkboxChecked && !priv) { settings.permissions[key] = ok; saveSettings(); }
    cb(ok);
  });
  ses.on('will-download', (_e, item) => {
    const name = item.getFilename(); const win = BrowserWindow.getAllWindows()[0];
    if (RISKY.test(name) && dialog.showMessageBoxSync(win, { type: 'warning', buttons: ['Keep', 'Cancel'], defaultId: 1, message: `"${name}" can run code on your computer. Only keep it if you trust the source.` }) === 1) return item.cancel();
    let p = path.join(app.getPath('downloads'), name), i = 1; const { name: b, ext } = path.parse(name);
    while (fs.existsSync(p)) p = path.join(app.getPath('downloads'), `${b} (${i++})${ext}`);
    item.setSavePath(p);
    const id = Date.now() + Math.random(); const rec = { id, name: path.basename(p), path: p, state: 'progressing', received: 0, total: item.getTotalBytes() };
    dls.set(id, rec); const push = () => wins.forEach((w) => w.win.webContents.send('dl', null));
    item.on('updated', () => { rec.received = item.getReceivedBytes(); push(); });
    item.once('done', (_ev, st) => { rec.state = st; if (!priv) db.prepare('INSERT INTO downloads(name,path,state,ts) VALUES(?,?,?,?)').run(rec.name, rec.path, st, Date.now()); dls.delete(id); push(); });
  });
}

/* ---------- windows & tabs ---------- */
function createWindow(priv, urls) {
  const win = new BrowserWindow({ width: 1280, height: 820, minWidth: 700, minHeight: 420, backgroundColor: '#1b1d23', title: priv ? 'NOVA (Private)' : 'NOVA',
    webPreferences: { preload: path.join(__dirname, '../preload/preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  win.setMenuBarVisibility(false);
  const w = { win, priv, tabs: new Map(), active: null, nextId: 1, overlay: false, closed: [], partition: priv ? 'nova-private-' + Date.now() : 'persist:nova' };
  wins.add(w); prepare(session.fromPartition(w.partition), priv);
  win.loadFile(path.join(__dirname, '../renderer/index.html'));
  win.webContents.on('before-input-event', (e, i) => shortcut(w, e, i));
  win.on('resize', () => layout(w));
  win.on('close', () => { if (!priv) saveSession(w); });
  win.on('closed', () => {
    wins.delete(w);
    if (priv) { const s = session.fromPartition(w.partition); s.clearStorageData().then(() => s.clearCache()).catch(() => {}); }
  });
  win.webContents.once('did-finish-load', () => { (urls && urls.length ? urls : [settings.home]).forEach((u) => addTab(w, u)); });
  return w;
}
function shortcut(w, e, i) {
  if (i.type !== 'keyDown') return;
  const c = i.control || i.meta; const k = i.key.toLowerCase(); const t = w.tabs.get(w.active);
  const hit = (f) => { e.preventDefault(); f(); };
  if (c && k === 't' && !i.shift) hit(() => addTab(w, ''));
  else if (c && k === 't' && i.shift) hit(() => reopen(w));
  else if (c && k === 'w') hit(() => closeTab(w, w.active));
  else if (c && k === 'l') hit(() => w.win.webContents.send('focus-address', null));
  else if (c && k === 'r' && t) hit(() => t.view.webContents.reload());
  else if (c && k === 'tab') hit(() => { const ids = [...w.tabs.keys()]; select(w, ids[(ids.indexOf(w.active) + 1) % ids.length]); });
  else if (k === 'f12' && t) hit(() => t.view.webContents.toggleDevTools());
}
function addTab(w, url) {
  const view = new WebContentsView({ webPreferences: { partition: w.partition, contextIsolation: true, nodeIntegration: false, sandbox: true } });
  const t = { id: w.nextId++, view, blocked: 0, pinned: false, title: 'New tab', favicon: '', loading: false };
  w.tabs.set(t.id, t); const wc = view.webContents; const push = () => pushState(w);
  wc.setWindowOpenHandler(({ url: u }) => { if (/^https?:/.test(u)) addTab(w, u); return { action: 'deny' }; });
  wc.on('page-title-updated', (_e, title) => {
    t.title = title; push();
    if (!w.priv && /^https?:/.test(wc.getURL())) db.prepare('UPDATE history SET title=? WHERE id=(SELECT MAX(id) FROM history WHERE url=?)').run(title, wc.getURL());
  });
  wc.on('page-favicon-updated', (_e, f) => { t.favicon = f[0] || ''; push(); });
  wc.on('did-start-loading', () => { t.loading = true; push(); });
  wc.on('did-stop-loading', () => { t.loading = false; push(); });
  wc.on('did-start-navigation', (d) => { if (d.isMainFrame && !d.isSameDocument) t.blocked = 0; });
  wc.on('did-navigate', (_e, u) => { record(w, t, u); push(); });
  wc.on('did-navigate-in-page', (_e, u, main) => { if (main) { record(w, t, u); push(); } });
  wc.on('audio-state-changed', push);
  wc.on('render-process-gone', () => { t.title = 'Page crashed - press reload'; push(); });
  wc.on('before-input-event', (e, i) => shortcut(w, e, i));
  w.win.contentView.addChildView(view);
  wc.loadURL(toUrl(url || settings.home)); select(w, t.id);
}
function record(w, t, u) { if (!w.priv && /^https?:/.test(u)) db.prepare('INSERT INTO history(url,title,ts) VALUES(?,?,?)').run(u, t.title, Date.now()); }
function select(w, id) { if (!w.tabs.has(id)) return; w.active = id; layout(w); pushState(w); }
function closeTab(w, id) {
  const t = w.tabs.get(id); if (!t) return;
  const u = t.view.webContents.getURL(); if (/^https?:/.test(u) && !w.priv) w.closed.push(u);
  w.win.contentView.removeChildView(t.view); t.view.webContents.close(); w.tabs.delete(id);
  if (!w.tabs.size) return addTab(w, '');
  if (w.active === id) w.active = [...w.tabs.keys()].pop();
  layout(w); pushState(w);
}
function reopen(w) { const u = w.closed.pop(); if (u) addTab(w, u); }
function layout(w) {
  if (w.win.isDestroyed()) return; const [cw, ch] = w.win.getContentSize();
  for (const t of w.tabs.values()) { const on = t.id === w.active; t.view.setVisible(on && !w.overlay); if (on) t.view.setBounds({ x: 0, y: CHROME_H, width: cw, height: Math.max(0, ch - CHROME_H) }); }
}
function pushState(w) {
  if (w.win.isDestroyed()) return; const t = w.tabs.get(w.active); const wc = t && t.view.webContents; const url = wc ? wc.getURL() : '';
  w.win.webContents.send('state', {
    priv: w.priv, active: w.active, url, theme: settings.theme, accent: settings.accent, protection: settings.blocker && !settings.allowlist.includes(hostOf(url)),
    canBack: !!wc && wc.navigationHistory.canGoBack(), canFwd: !!wc && wc.navigationHistory.canGoForward(), totalBlocked,
    bookmarked: !!db.prepare('SELECT 1 FROM bookmarks WHERE url=?').get(url), blocked: t ? t.blocked : 0,
    tabs: [...w.tabs.values()].map((x) => ({ id: x.id, title: x.title, favicon: x.favicon, loading: x.loading, pinned: x.pinned, muted: x.view.webContents.audioMuted, audible: x.view.webContents.isCurrentlyAudible() }))
  });
}
function saveSession(w) { const u = [...w.tabs.values()].map((t) => t.view.webContents.getURL()).filter((x) => /^https?:/.test(x)); if (u.length) { settings.session = u; saveSettings(); } }

/* ---------- IPC (validated; sender must be a NOVA chrome window) ---------- */
const winOf = (e) => [...wins].find((w) => w.win.webContents === e.sender);
ipcMain.handle('act', (e, a) => {
  const w = winOf(e); if (!w || !a || typeof a.type !== 'string') return;
  const t = w.tabs.get(w.active); const wc = t && t.view.webContents; const id = Number.isInteger(a.id) ? a.id : null;
  switch (a.type) {
    case 'new': addTab(w, typeof a.url === 'string' ? a.url : ''); break;
    case 'close': closeTab(w, id ?? w.active); break;
    case 'select': if (id) select(w, id); break;
    case 'nav': if (wc && typeof a.value === 'string') wc.loadURL(toUrl(a.value)); break;
    case 'back': if (wc) wc.navigationHistory.goBack(); break;
    case 'fwd': if (wc) wc.navigationHistory.goForward(); break;
    case 'reload': if (wc) wc.reload(); break;
    case 'home': if (wc) wc.loadURL(settings.home); break;
    case 'devtools': if (wc) wc.toggleDevTools(); break;
    case 'reopen': reopen(w); break;
    case 'private': createWindow(true); break;
    case 'overlay': w.overlay = !!a.value; layout(w); break;
    case 'pin': { const x = w.tabs.get(id); if (x) { x.pinned = !x.pinned; pushState(w); } break; }
    case 'mute': { const x = w.tabs.get(id); if (x) { x.view.webContents.audioMuted = !x.view.webContents.audioMuted; pushState(w); } break; }
    case 'bookmark': if (wc) { const u = wc.getURL(); if (db.prepare('SELECT 1 FROM bookmarks WHERE url=?').get(u)) db.prepare('DELETE FROM bookmarks WHERE url=?').run(u); else if (/^https?:/.test(u)) db.prepare('INSERT INTO bookmarks VALUES(?,?,?)').run(u, t.title, Date.now()); pushState(w); } break;
    case 'shield': if (wc) { const h = hostOf(wc.getURL()); const i = settings.allowlist.indexOf(h); if (i >= 0) settings.allowlist.splice(i, 1); else settings.allowlist.push(h); saveSettings(); wc.reload(); pushState(w); } break;
    case 'clear': { const ses = session.fromPartition(w.partition); ses.clearStorageData().then(() => ses.clearCache()); if (!w.priv) db.exec('DELETE FROM history'); break; }
  }
});
ipcMain.handle('suggest', async (e, q) => {
  if (!winOf(e) || !q.trim()) return [];
  const like = '%' + q.replace(/[%_]/g, '') + '%';
  const hist = db.prepare('SELECT DISTINCT url,title FROM history WHERE url LIKE ? OR title LIKE ? ORDER BY id DESC LIMIT 4').all(like, like).map((r) => ({ kind: 'history', text: r.url, sub: r.title }));
  let web = [];
  try { const r = await net.fetch('https://duckduckgo.com/ac/?type=list&q=' + encodeURIComponent(q)); web = (await r.json())[1].slice(0, 5).map((s) => ({ kind: 'search', text: s })); } catch {}
  return [...hist, ...web];
});
ipcMain.handle('data', (e, k) => {
  if (!winOf(e)) return [];
  if (k === 'history') return db.prepare('SELECT url,title FROM history ORDER BY id DESC LIMIT 200').all();
  if (k === 'bookmarks') return db.prepare('SELECT url,title FROM bookmarks ORDER BY ts DESC').all();
  if (k === 'downloads') return [...[...dls.values()].map((d) => ({ name: d.name, state: d.state + (d.total ? ` ${Math.round(100 * d.received / d.total)}%` : '') })), ...db.prepare('SELECT name,state FROM downloads ORDER BY id DESC LIMIT 100').all()];
  return [];
});
ipcMain.handle('settings:get', () => settings);
ipcMain.handle('settings:set', (e, k, v) => {
  if (!winOf(e) || !(k in DEFAULTS) || k === 'session' || k === 'permissions') return;
  if (typeof v !== typeof DEFAULTS[k] || Array.isArray(v) !== Array.isArray(DEFAULTS[k])) return;
  if (k === 'engine' && v !== 'custom' && !ENGINES[v]) return;
  if (k === 'home' && !/^https?:\/\//.test(v)) return;
  if (k === 'accent' && !/^#[0-9a-f]{6}$/i.test(v)) return;
  settings[k] = v; saveSettings();
  if (k === 'customHosts') loadBlocklist();
  if (k === 'doh') applyDoh();
  wins.forEach(pushState);
});
function applyDoh() { app.configureHostResolver(settings.doh ? { secureDnsMode: 'secure', secureDnsServers: ['https://cloudflare-dns.com/dns-query'] } : { secureDnsMode: 'automatic' }); }

/* ---------- lifecycle ---------- */
app.on('web-contents-created', (_e, wc) => { wc.on('will-attach-webview', (ev) => ev.preventDefault()); });
app.whenReady().then(() => {
  loadSettings(); initDb(); loadBlocklist(); applyDoh();
  createWindow(false, settings.session);
  setInterval(() => wins.forEach((w) => { if (!w.priv) saveSession(w); }), 30000);
  app.on('activate', () => { if (!wins.size) createWindow(false); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
