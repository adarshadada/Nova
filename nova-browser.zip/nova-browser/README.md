# NOVA Browser (v0.1 core)
Electron + real Chromium `WebContentsView`s (no iframes). Context isolation on, sandbox on, no Node in web content, strict CSP on the UI, validated IPC.

## Commands
    npm install          # install deps (rebuilds better-sqlite3 for Electron)
    npm start            # run
    npm run dist:win     # Windows NSIS installer  -> dist/
    npm run dist:linux   # AppImage + deb          -> dist/
Build each target on its own OS (or use the GitHub Actions workflow).

## Implemented
Tabs (new/close/switch/pin/mute/reopen, Ctrl+T/W/L/R/Tab, Ctrl+Shift+T, F12), address bar with URL detection + history & DuckDuckGo suggestions, 6 engines + custom, request-level tracker blocker (real counters, per-site allowlist, custom hosts, DNT/GPC headers), SQLite history/bookmarks/downloads, download manager with risky-file warning, permission prompts (remembered), private windows (in-memory partition, no history, wiped on close), clear data, DoH toggle, themes/accent, session restore (also every 30 s), crash message.

## Not implemented yet / limitations
Extensions (Electron's MV3 support is partial - not faked), EasyList parsing & cosmetic filtering (starter host list only), profiles, tab groups/drag reorder/vertical tabs, split view, reader mode, PiP, screenshot, QR, find-in-page, translation, new-tab dashboard, password manager, Lucide icons (unicode glyphs used), shortcut customization. Not yet run-tested: build and smoke-test locally before relying on it.
